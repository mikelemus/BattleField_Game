package com.mindhub.salvo;

public enum State {
    PLAY,WAITING_SHIPS,WAITING_OPPONENT,WAIT,TIE,WIN,LOST
}
